
/********************************************************
*	  ____   _____
*	 / ___| | ____|
*	| |  _  |  _|
*	| |_| | | |___
*	 \____| |_____|
* _______________________________________________________
*
* FILE TITLE: 
*
* FILE AUTOHOR:
*
* FILE PURPOSE: 
*
*********************************************************/

#pragma once

namespace GE_EngineCore
{
	class $safeitemname$
	{
		public:
	
			$safeitemname$();
			virtual ~$safeitemname$();

		protected:
	


		private:


	};
}

